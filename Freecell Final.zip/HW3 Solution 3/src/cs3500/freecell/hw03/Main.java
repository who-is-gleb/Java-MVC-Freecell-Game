package cs3500.freecell.hw03;

import java.io.InputStreamReader;

import cs3500.freecell.hw02.Card;
import cs3500.freecell.hw02.FreecellOperations;
import cs3500.freecell.hw04.FreecellModelCreator;

/**
 * Run a Tic Tac Toe game interactively on the console.
 */
public class Main {
  /**
   * Run a Tic Tac Toe game interactively on the console.
   */
  public static void main(String[] args) {
    FreecellOperations<Card> model = FreecellModelCreator
            .create(FreecellModelCreator.GameType.MULTIMOVE);

    new FreecellController(new InputStreamReader(System.in), System.out)
            .playGame(model.getDeck(), model, 4, 2, false);
  }
}